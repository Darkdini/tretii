// game.js — игровая логика сервера. Без DOM, без браузера.
// Те же сущности что были в клиенте: гексы, здания, юниты, бой.

// ============== СТАТИЧЕСКИЕ ТАБЛИЦЫ ==============

const RACES = {
  human: { name: "Люди",  bonus: "Железо +20%", glyph: "⚔" },
  elf:   { name: "Эльфы", bonus: "Дерево +20%", glyph: "🏹" },
  dwarv: { name: "Гномы", bonus: "Камень +20%", glyph: "⛏" },
};

const RES = ['gold','wood','stone','food','iron','people','magic','rare'];
const RES_LABEL = {
  gold:'Золото', wood:'Дерево', stone:'Камень', food:'Еда',
  iron:'Железо', people:'Люди', magic:'Магия', rare:'Реликвия',
};
const RES_GLYPH = {
  gold:'🪙', wood:'🌲', stone:'⛰', food:'🌾',
  iron:'🟫', people:'👥', magic:'🧪', rare:'⚪',
};

const BUILDINGS = {
  castle:    { name:"Ратуша",            glyph:"🏰", desc:"Главное здание королевства.",
               cost:{wood:200,stone:200,iron:50,food:0}, time:120, max:10, unique:true },
  storage:   { name:"Склад",             glyph:"📦", desc:"Хранит ресурсы.",
               cost:{wood:80,stone:120,iron:0,food:0}, time:60, max:10 },
  market:    { name:"Рынок",             glyph:"🏪", desc:"Торговля между расами.",
               cost:{wood:120,stone:60,iron:0,food:0}, time:90, max:10, req:{castle:2} },
  barracks:  { name:"Казарма",           glyph:"🛡", desc:"Тренировка лёгких воинов.",
               cost:{wood:80,stone:120,iron:60,food:0}, time:120, max:10, req:{castle:2} },
  smithy:    { name:"Кузница",           glyph:"🔨", desc:"Усиление армии.",
               cost:{wood:60,stone:120,iron:80,food:0}, time:120, max:10, req:{castle:3} },
  stables:   { name:"Конюшня",           glyph:"🐴", desc:"Тренировка кавалерии.",
               cost:{wood:140,stone:80,iron:60,food:40}, time:160, max:10, req:{castle:3} },
  workshop:  { name:"Мастерская",        glyph:"⚙", desc:"Прочность зданий.",
               cost:{wood:80,stone:160,iron:40,food:0}, time:120, max:10, req:{castle:3} },
  university:{ name:"Университет",       glyph:"📚", desc:"Святилище науки.",
               cost:{wood:200,stone:200,iron:100,food:0}, time:300, max:10, req:{castle:5} },
  magtower:  { name:"Башня артефактов",  glyph:"🗼", desc:"Активирует артефакты.",
               cost:{wood:150,stone:300,iron:100,food:0}, time:300, max:10, req:{castle:5} },
  magscool:  { name:"Академия магов",    glyph:"🧙", desc:"Тренировка магов.",
               cost:{wood:300,stone:200,iron:100,food:0}, time:360, max:10, req:{castle:5} },
  beer:      { name:"Пивоварня",         glyph:"🍺", desc:"Любимый напиток.",
               cost:{wood:100,stone:60,iron:0,food:30}, time:120, max:10, req:{castle:3} },
  tavern:    { name:"Таверна",           glyph:"🍷", desc:"Наёмники забредают сюда.",
               cost:{wood:80,stone:60,iron:20,food:60}, time:90, max:10, req:{castle:3} },
  alchimia:  { name:"Лавка алхимиков",   glyph:"⚗", desc:"Зелья и рецепты.",
               cost:{wood:60,stone:120,iron:80,food:0}, time:180, max:10, req:{castle:4} },
  secret:    { name:"Тайник",            glyph:"🗝", desc:"Прячет часть ресурсов.",
               cost:{wood:120,stone:60,iron:30,food:0}, time:90, max:10, req:{castle:2} },
  resident:  { name:"Центр шпионажа",    glyph:"🕵", desc:"Разведка и шпионы.",
               cost:{wood:100,stone:100,iron:50,food:0}, time:180, max:10, req:{castle:5} },
  expedition:{ name:"Лагерь археологов", glyph:"⛏", desc:"Поиск артефактов.",
               cost:{wood:160,stone:80,iron:0,food:0}, time:200, max:10, req:{castle:4} },
  traveler:  { name:"Дом путешественника",glyph:"🏕",desc:"Новые замки.",
               cost:{wood:200,stone:200,iron:100,food:50}, time:240, max:10, req:{castle:6} },
  wisdom:    { name:"Дом мудрецов",      glyph:"📖", desc:"Жилище учёных.",
               cost:{wood:80,stone:60,iron:30,food:0}, time:120, max:10, req:{castle:3} },
  wall:      { name:"Стены",             glyph:"🏛", desc:"Защита замка.",
               cost:{wood:60,stone:200,iron:40,food:0}, time:150, max:10, req:{castle:2} },
  guard:     { name:"Караульная башня",  glyph:"🗼", desc:"Обнаружение атак.",
               cost:{wood:120,stone:160,iron:60,food:0}, time:200, max:10, req:{castle:3} },
  treasury:  { name:"Сокровищница",      glyph:"💰", desc:"Хранение золота.",
               cost:{wood:100,stone:200,iron:80,food:0}, time:180, max:10, req:{castle:5} },
};

const LAND_BUILDINGS = {
  sawmill: { name:"Лесопилка",   glyph:"🪓", desc:"Добыча древесины.",
             cost:{wood:40,stone:60,iron:10,food:0}, time:60, max:10, produces:'wood', basePerHour:60, terrain:'forest' },
  stone:   { name:"Каменоломня", glyph:"⛰", desc:"Добыча камня.",
             cost:{wood:80,stone:30,iron:10,food:0}, time:60, max:10, produces:'stone', basePerHour:60, terrain:'stone-deposit' },
  iron:    { name:"Шахта",       glyph:"⛏", desc:"Добыча железа.",
             cost:{wood:80,stone:80,iron:0,food:0}, time:80, max:10, produces:'iron', basePerHour:50, terrain:'stone-deposit' },
  farm:    { name:"Ферма",       glyph:"🌾", desc:"Производство еды.",
             cost:{wood:60,stone:30,iron:0,food:0}, time:50, max:10, produces:'food', basePerHour:80, terrain:'field' },
  house:   { name:"Хибара",      glyph:"🏘", desc:"Жилой дом.",
             cost:{wood:80,stone:40,iron:0,food:20}, time:70, max:10, produces:'people', basePerHour:8, capacity:50, terrain:'deep-grass' },
};

const UNITS = {
  swordsman: { name:"Мечник",   glyph:"⚔",  cost:{wood:50,stone:0,iron:80,food:30}, people:1,
               atk:30, def:35, hp:40, speed:18, carry:60, upkeep:2, trainTime:60, building:'barracks', reqLvl:1 },
  spearman:  { name:"Копейщик", glyph:"🔱", cost:{wood:80,stone:0,iron:30,food:30}, people:1,
               atk:20, def:50, hp:35, speed:22, carry:50, upkeep:2, trainTime:50, building:'barracks', reqLvl:1 },
  archer:    { name:"Лучник",   glyph:"🏹", cost:{wood:80,stone:0,iron:20,food:30}, people:1,
               atk:45, def:15, hp:25, speed:15, carry:40, upkeep:2, trainTime:80, building:'barracks', reqLvl:3 },
  knight:    { name:"Рыцарь",   glyph:"🐎", cost:{wood:60,stone:0,iron:140,food:80}, people:1,
               atk:80, def:60, hp:80, speed:8, carry:100, upkeep:5, trainTime:200, building:'stables', reqLvl:1 },
  wizard:    { name:"Маг",      glyph:"🧙", cost:{wood:30,stone:0,iron:30,food:60}, people:1,
               atk:90, def:20, hp:35, speed:12, carry:30, upkeep:4, trainTime:240, building:'magscool', reqLvl:1 },
};

const CASTLE_R = 4, LANDS_R = 5, WORLD_R = 6;

// ============== HEX-ГЕОМЕТРИЯ ==============

function hexInRadius(R) {
  const cells = [];
  for (let q = -R; q <= R; q++) {
    for (let r = Math.max(-R, -q-R); r <= Math.min(R, -q+R); r++) {
      cells.push({ q, r });
    }
  }
  return cells;
}
function hexDist(a, b) {
  return (Math.abs(a.q-b.q) + Math.abs(a.q+a.r - b.q-b.r) + Math.abs(a.r-b.r)) / 2;
}

// ============== СОЗДАНИЕ ИГРОКА ==============

function createPlayer(race, kingdom) {
  const now = Date.now();
  const p = {
    race, kingdom,
    ts: now, created: now,
    res:    { gold:1000, wood:500, stone:500, food:500, iron:200, people:50, magic:0, rare:0 },
    resMax: { gold:5000, wood:2000, stone:2000, food:2000, iron:2000, people:100, magic:100, rare:100 },
    castle: [], lands: [],
    queue: [], trainQueue: [], army: {}, marches: [],
    reports: [{ t: now, txt: `Добро пожаловать, владыка ${kingdom}!`, kind: 'info' }],
    worldPos: null,    // {q,r} — заполнится при размещении на карте мира
  };

  // Замок
  for (const c of hexInRadius(CASTLE_R)) {
    p.castle.push({ q: c.q, r: c.r, type: 'castle-grass', bldId: null, level: 0 });
  }
  setBld(p.castle, 0, 0, 'castle', 1);
  setBld(p.castle, 1, 0, 'storage', 1);

  // Земли с биомами (детерминированно от имени, чтобы у каждого свои)
  const seed = strHash(kingdom);
  let rnd = mulberry32(seed);
  for (const c of hexInRadius(LANDS_R)) {
    const dist = Math.max(Math.abs(c.q), Math.abs(c.r), Math.abs(c.q+c.r));
    let type = 'deep-grass';
    const noise = Math.sin(c.q*1.3 + seed) * Math.cos(c.r*1.7 + seed*1.7);
    if (c.r <= -2 && noise > 0) type = 'forest';
    else if (c.r <= -1 && noise > -0.3) type = 'forest';
    else if (c.q >= 2 && noise > 0) type = 'stone-deposit';
    else if (c.q >= 1 && c.r >= 1) type = 'field';
    else if (noise < -0.4) type = 'field';
    if (dist > LANDS_R) type = 'water';
    p.lands.push({ q: c.q, r: c.r, type, bldId: null, level: 0 });
  }
  // Стартовая ферма
  for (const c of p.lands) {
    if (c.type === 'field' && !c.bldId) {
      c.bldId = 'farm'; c.level = 1; break;
    }
  }
  return p;
}

function setBld(cells, q, r, bldId, level) {
  const c = cells.find(x => x.q === q && x.r === r);
  if (c) { c.bldId = bldId; c.level = level; }
}

// Простой PRNG
function mulberry32(a) {
  return function() {
    let t = a += 0x6D2B79F5;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
function strHash(s) {
  let h = 5381;
  for (const ch of s) h = ((h << 5) + h + ch.charCodeAt(0)) | 0;
  return h >>> 0;
}

// ============== СОЗДАНИЕ МИРА (общий) ==============

function createWorld() {
  // Карта мира — все клетки. Пустые, оазисы, бандиты. Игроки добавятся позже.
  const cells = hexInRadius(WORLD_R);
  const map = {};
  const rnd = mulberry32(20260511);
  for (const c of cells) {
    const dist = Math.max(Math.abs(c.q), Math.abs(c.r), Math.abs(c.q+c.r));
    const k = `${c.q},${c.r}`;
    const r = rnd();
    if (r < 0.12) {
      const resKeys = ['wood','stone','food','iron','magic'];
      map[k] = { q:c.q, r:c.r, type:'oasis', resource: resKeys[Math.floor(rnd()*resKeys.length)] };
    } else if (r < 0.22) {
      map[k] = { q:c.q, r:c.r, type:'bandit', power: 50 + Math.floor(rnd()*250) };
    } else {
      map[k] = { q:c.q, r:c.r, type:'empty' };
    }
  }
  return map;
}

function placePlayerOnWorld(world, playerName, race) {
  // Находим свободную empty-клетку, ставим туда player
  const free = Object.values(world).filter(c => c.type === 'empty');
  if (!free.length) return null;
  const idx = strHash(playerName) % free.length;
  const cell = free[idx];
  cell.type = 'player';
  cell.player = playerName;
  cell.race = race;
  cell.lvl = 1;
  return { q: cell.q, r: cell.r };
}

// ============== БАЛАНС ==============

function buildingProduction(bldId, level, race) {
  const b = LAND_BUILDINGS[bldId];
  if (!b || !b.produces) return 0;
  let p = b.basePerHour * Math.pow(1.3, level - 1);
  if (race === 'human' && b.produces === 'iron')  p *= 1.2;
  if (race === 'elf'   && b.produces === 'wood')  p *= 1.2;
  if (race === 'dwarv' && b.produces === 'stone') p *= 1.2;
  return Math.round(p);
}
function capacityBonus(bldId, level) {
  if (bldId === 'storage')  return Math.round(500 * Math.pow(1.5, level - 1));
  if (bldId === 'treasury') return Math.round(200 * Math.pow(1.6, level - 1));
  const lb = LAND_BUILDINGS[bldId];
  if (lb && lb.capacity) return Math.round(lb.capacity * Math.pow(1.4, level - 1));
  return 0;
}
function nextBuildCost(bldId, currentLvl) {
  const def = BUILDINGS[bldId] || LAND_BUILDINGS[bldId]; if (!def) return null;
  const mul = Math.pow(1.6, currentLvl);
  return {
    wood:  Math.round((def.cost.wood ||0)*mul),
    stone: Math.round((def.cost.stone||0)*mul),
    iron:  Math.round((def.cost.iron ||0)*mul),
    food:  Math.round((def.cost.food ||0)*mul),
  };
}
function nextBuildTime(bldId, currentLvl, castleLvl=1) {
  const def = BUILDINGS[bldId] || LAND_BUILDINGS[bldId]; if (!def) return 60;
  let t = def.time * Math.pow(1.4, currentLvl);
  t *= Math.pow(0.92, castleLvl - 1);
  return Math.max(5, Math.round(t));
}
function getCastleLevel(p) {
  const c = p.castle.find(x => x.bldId === 'castle');
  return c ? c.level : 1;
}
function reqMet(p, bldId) {
  const def = BUILDINGS[bldId]; if (!def?.req) return true;
  for (const k in def.req) {
    let lvl = 0;
    for (const c of p.castle) if (c.bldId === k) lvl = Math.max(lvl, c.level);
    if (lvl < def.req[k]) return false;
  }
  return true;
}
function hasUnique(p, bldId) {
  if (!BUILDINGS[bldId]?.unique) return false;
  return p.castle.some(c => c.bldId === bldId);
}
function canAfford(p, cost) {
  for (const k in cost) if ((p.res[k]||0) < cost[k]) return false;
  return true;
}
function payCost(p, cost) {
  for (const k in cost) p.res[k] -= cost[k];
}
function computeRates(p) {
  const r = { gold:50, wood:0, stone:0, food:0, iron:0, people:0, magic:0, rare:0 };
  for (const c of p.lands) {
    if (!c.bldId) continue;
    const def = LAND_BUILDINGS[c.bldId];
    if (!def || !def.produces) continue;
    r[def.produces] += buildingProduction(c.bldId, c.level, p.race);
  }
  for (const uid in p.army) {
    const n = p.army[uid]; if (!n) continue;
    const u = UNITS[uid];
    if (u && u.upkeep) r.food -= n * u.upkeep;
  }
  return r;
}
function recomputeMaxes(p) {
  p.resMax = { gold:5000, wood:1000, stone:1000, food:1000, iron:1000, people:50, magic:100, rare:100 };
  for (const c of p.castle) {
    if (c.bldId === 'storage') {
      const cap = capacityBonus('storage', c.level);
      p.resMax.wood += cap; p.resMax.stone += cap; p.resMax.iron += cap; p.resMax.food += cap;
    }
    if (c.bldId === 'treasury') p.resMax.gold += capacityBonus('treasury', c.level);
  }
  for (const c of p.lands) {
    if (c.bldId === 'house') p.resMax.people += capacityBonus('house', c.level);
  }
  for (const k of RES) if (p.res[k] > p.resMax[k]) p.res[k] = p.resMax[k];
}
function addReport(p, txt, kind='info') {
  p.reports.push({ t: Date.now(), txt, kind });
  if (p.reports.length > 100) p.reports.shift();
}

// ============== БОЙ ==============

function resolveBattle(p, world, march) {
  let atkPow = 0;
  for (const uid in march.units) atkPow += march.units[uid] * UNITS[uid].atk;

  const k = `${march.target.q},${march.target.r}`;
  const cell = world[k];
  if (!cell) return { win:false, survivors:{}, losses:march.units, lossesTxt:'все погибли', loot:null };

  let defPow = 0, lootMult = 1;
  if (cell.type === 'bandit') { defPow = cell.power || 100; }
  else if (cell.type === 'oasis') { defPow = 30; }
  else if (cell.type === 'player') { defPow = (cell.lvl||1) * 200; lootMult = 0.3; }

  const win = atkPow > defPow * 0.9;
  const lossRatio = win
    ? Math.min(0.6, defPow / Math.max(1, atkPow) * 0.5)
    : Math.min(0.95, defPow / Math.max(1, atkPow) * 0.8);

  const survivors = {}, losses = {};
  for (const uid in march.units) {
    const start = march.units[uid];
    const lost = Math.min(start, Math.round(start * lossRatio));
    const surv = start - lost;
    if (surv > 0) survivors[uid] = surv;
    if (lost > 0) losses[uid] = lost;
  }
  const lossesTxt = Object.entries(losses).map(([u,n]) => `${UNITS[u].name}×${n}`).join(', ') || 'нет';

  let loot = null;
  if (win) {
    if (cell.type === 'bandit') {
      const total = (cell.power||100) * 3;
      loot = { gold: Math.round(total*0.4), wood: Math.round(total*0.2), stone: Math.round(total*0.2), food: Math.round(total*0.2) };
      cell.type = 'empty'; delete cell.power;
    } else if (cell.type === 'oasis') {
      loot = { [cell.resource]: 500 };
      const r = cell.resource;
      cell.type = 'empty'; delete cell.resource;
      addReport(p, `🏆 Захвачен оазис ${RES_LABEL[r]}!`, 'capture');
    } else if (cell.type === 'player') {
      const total = (cell.lvl||1) * 300 * lootMult;
      loot = { gold: Math.round(total*0.5), wood: Math.round(total*0.2), stone: Math.round(total*0.15), iron: Math.round(total*0.15) };
    }
    if (loot) {
      let cap = 0;
      for (const uid in survivors) cap += survivors[uid] * UNITS[uid].carry;
      let totalLoot = Object.values(loot).reduce((a,b)=>a+b,0);
      if (totalLoot > cap) {
        const k2 = cap / totalLoot;
        for (const r2 in loot) loot[r2] = Math.floor(loot[r2]*k2);
      }
    }
  }
  return { win, survivors, losses, lossesTxt, loot };
}

// ============== ТИК ==============

function tickPlayer(p, world) {
  const now = Date.now();
  const dt = Math.max(0, (now - p.ts) / 1000);
  p.ts = now;
  if (dt <= 0) return;

  // 1) Ресурсы
  const rates = computeRates(p);
  for (const r of RES) {
    if (rates[r]) {
      p.res[r] = Math.max(0, Math.min(p.resMax[r] || 9e9, p.res[r] + rates[r] * dt / 3600));
    }
  }

  // 2) Стройка
  for (let i = p.queue.length - 1; i >= 0; i--) {
    const job = p.queue[i];
    if (now >= job.end) {
      const cells = job.loc === 'castle' ? p.castle : p.lands;
      const cell = cells.find(c => c.q === job.q && c.r === job.r);
      if (cell) { cell.bldId = job.bldId; cell.level = job.toLvl; }
      p.queue.splice(i, 1);
      const def = BUILDINGS[job.bldId] || LAND_BUILDINGS[job.bldId];
      addReport(p, `🏗 «${def.name}» ур. ${job.toLvl} построено`, 'build');
    }
  }

  // 3) Тренировка — по 1 юниту за batchTime
  for (let i = p.trainQueue.length - 1; i >= 0; i--) {
    const job = p.trainQueue[i];
    while (job.count > 0 && now >= job.nextDone) {
      p.army[job.uid] = (p.army[job.uid] || 0) + 1;
      job.count -= 1;
      job.totalDone = (job.totalDone || 0) + 1;
      if (job.count > 0) job.nextDone += job.batchTime * 1000;
    }
    if (job.count <= 0) {
      p.trainQueue.splice(i, 1);
      addReport(p, `👥 Тренировка завершена: ${job.totalDone}× ${UNITS[job.uid].name}`, 'train');
    }
  }

  // 4) Походы
  for (let i = p.marches.length - 1; i >= 0; i--) {
    const m = p.marches[i];
    if (m.phase === 'going' && now >= m.arriveAt) {
      // Запоминаем имя цели ДО боя — потому что resolveBattle может стереть бандита/оазис
      m.targetNameSnapshot = targetName(world, m);
      const result = resolveBattle(p, world, m);
      m.phase = 'returning';
      m.returnAt = now + (m.arriveAt - m.startAt);
      m.battleResult = result;
      m.units = result.survivors;
      m.loot = result.loot;
      const alive = Object.values(result.survivors).reduce((a,b)=>a+b,0);
      if (alive === 0) {
        p.marches.splice(i, 1);
        addReport(p, `💀 Войско уничтожено в бою у ${m.targetNameSnapshot}`, 'battle-loss');
      }
    } else if (m.phase === 'returning' && now >= m.returnAt) {
      for (const uid in m.units) p.army[uid] = (p.army[uid]||0) + m.units[uid];
      if (m.loot) {
        for (const k in m.loot) p.res[k] = Math.min(p.resMax[k]||9e9, (p.res[k]||0) + m.loot[k]);
      }
      p.marches.splice(i, 1);
      const r = m.battleResult;
      const lootTxt = r.loot ? Object.entries(r.loot).filter(([,v])=>v).map(([k,v])=>`${RES_GLYPH[k]}+${v}`).join(' ') : '';
      addReport(p,
        `${r.win?'🏆 Победа':'⚔ Поражение'} у ${m.targetNameSnapshot || '?'} · потери: ${r.lossesTxt}` +
        (lootTxt?` · добыча: ${lootTxt}`:''),
        r.win ? 'battle-win' : 'battle-loss');
    }
  }
  recomputeMaxes(p);
}

function targetName(world, m) {
  const c = world[`${m.target.q},${m.target.r}`];
  if (!c) return '?';
  if (c.type === 'bandit') return 'Анархистов';
  if (c.type === 'oasis')  return `Оазис ${RES_LABEL[c.resource] || ''}`;
  if (c.type === 'player') return c.player;
  return '?';
}

// ============== КОМАНДЫ КЛИЕНТА (валидируются на сервере) ==============

function cmdBuild(p, { loc, q, r, bldId }) {
  if (loc !== 'castle' && loc !== 'lands') return err('bad loc');
  const cells = loc === 'castle' ? p.castle : p.lands;
  const cell = cells.find(c => c.q === q && c.r === r);
  if (!cell) return err('cell not found');
  if (cell.type === 'water') return err('cannot build on water');
  if (p.queue.filter(j => j.loc === loc).length >= 2) return err('queue full');

  const isCastleLoc = loc === 'castle';
  const defs = isCastleLoc ? BUILDINGS : LAND_BUILDINGS;
  const def = defs[bldId];
  if (!def) return err('unknown building');
  // Если в клетке уже есть здание — апгрейдим его же
  const curLvl = cell.bldId === bldId ? cell.level : 0;
  if (cell.bldId && cell.bldId !== bldId) return err('cell occupied');
  if (curLvl >= (def.max||10)) return err('max level');
  if (!isCastleLoc && def.terrain && def.terrain !== cell.type) return err('wrong terrain');
  if (isCastleLoc && def.unique && hasUnique(p, bldId) && cell.bldId !== bldId) return err('unique already built');
  if (isCastleLoc && !reqMet(p, bldId)) return err('requirements not met');

  const cost = nextBuildCost(bldId, curLvl);
  if (!canAfford(p, cost)) return err('not enough resources');
  payCost(p, cost);
  const time = nextBuildTime(bldId, curLvl, getCastleLevel(p));
  const start = Date.now();
  p.queue.push({ loc, q, r, bldId, toLvl: curLvl+1, start, end: start + time*1000 });
  return ok({ time });
}

function cmdDemolish(p, { loc, q, r }) {
  const cells = loc === 'castle' ? p.castle : p.lands;
  const cell = cells.find(c => c.q === q && c.r === r);
  if (!cell || !cell.bldId) return err('nothing here');
  if (cell.bldId === 'castle') return err('cannot demolish castle');
  cell.bldId = null; cell.level = 0;
  recomputeMaxes(p);
  return ok();
}

function cmdTrain(p, { bldQ, bldR, uid, count }) {
  const u = UNITS[uid]; if (!u) return err('unknown unit');
  const bldCell = p.castle.find(c => c.q === bldQ && c.r === bldR);
  if (!bldCell || bldCell.bldId !== u.building) return err('wrong building');
  if (bldCell.level < u.reqLvl) return err('building level too low');
  if (p.trainQueue.length >= 4) return err('train queue full');

  count = Math.max(1, Math.floor(count));
  // Ограничение по ресурсам и людям
  let max = count;
  for (const k of ['wood','stone','iron','food']) {
    if (u.cost[k] > 0) max = Math.min(max, Math.floor((p.res[k]||0) / u.cost[k]));
  }
  max = Math.min(max, Math.floor((p.res.people||0) / u.people));
  if (max <= 0) return err('not enough resources or people');
  count = Math.min(count, max);

  const totalCost = { wood:u.cost.wood*count, stone:u.cost.stone*count, iron:u.cost.iron*count, food:u.cost.food*count };
  payCost(p, totalCost);
  p.res.people -= u.people * count;

  const now = Date.now();
  p.trainQueue.push({ uid, count, batchTime: u.trainTime, nextDone: now + u.trainTime*1000, startedAt: now });
  addReport(p, `👥 Начат найм: ${count}× ${u.name}`, 'train');
  return ok({ count });
}

function cmdAttack(p, world, { targetQ, targetR, units }) {
  const cell = world[`${targetQ},${targetR}`];
  if (!cell) return err('target not found');
  if (cell.type !== 'bandit' && cell.type !== 'oasis' && cell.type !== 'player')
    return err('cannot attack this');
  if (cell.type === 'player' && cell.player === p.kingdom) return err('cannot attack yourself');
  // Валидация юнитов
  let totalCount = 0, slowest = 0;
  for (const uid in units) {
    const n = Math.floor(units[uid]);
    if (n < 0) return err('negative units');
    if (n === 0) continue;
    if (!UNITS[uid]) return err('unknown unit');
    if ((p.army[uid]||0) < n) return err('not enough units of ' + uid);
    totalCount += n;
    slowest = Math.max(slowest, UNITS[uid].speed);
  }
  if (totalCount === 0) return err('no units selected');

  // Списываем из армии
  for (const uid in units) p.army[uid] -= units[uid];
  for (const uid in units) if (p.army[uid] === 0) delete p.army[uid];

  const myPos = p.worldPos || { q:0, r:0 };
  const dist = Math.max(1, hexDist(myPos, { q: targetQ, r: targetR }));
  const travelMs = slowest * dist * 1000;
  const now = Date.now();
  p.marches.push({
    type: 'attack',
    target: { q: targetQ, r: targetR },
    units: Object.fromEntries(Object.entries(units).filter(([,v])=>v>0)),
    startAt: now,
    arriveAt: now + travelMs,
    phase: 'going',
  });
  addReport(p, `⚔ Войско отправлено к ${targetName(world, { target:{q:targetQ,r:targetR} })} (${totalCount} воинов)`, 'march');
  return ok({ travelMs });
}

function ok(extra={}) { return { ok: true, ...extra }; }
function err(msg) { return { ok: false, error: msg }; }

module.exports = {
  RACES, RES, RES_LABEL, RES_GLYPH,
  BUILDINGS, LAND_BUILDINGS, UNITS,
  CASTLE_R, LANDS_R, WORLD_R,
  hexInRadius, hexDist,
  createPlayer, createWorld, placePlayerOnWorld,
  tickPlayer, recomputeMaxes, computeRates,
  cmdBuild, cmdDemolish, cmdTrain, cmdAttack,
  // экспорт для клиента (констант)
  nextBuildCost, nextBuildTime, getCastleLevel, reqMet, hasUnique,
};
