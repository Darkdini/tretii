// server.js — главный сервер игры.
// HTTP REST API + WebSocket для push-обновлений + статика клиента.

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const url = require('url');
const wss = require('./ws');
const G = require('./game');

const PORT = parseInt(process.env.PORT || '7777', 10);
const STATE_FILE = path.join(__dirname, 'state.json');

// ============== СОСТОЯНИЕ СЕРВЕРА ==============
let STATE = {
  players: {},   // username -> player object
  world: null,   // глобальная карта мира
  sessions: {},  // sessionId -> username
};

function loadState() {
  try {
    const raw = fs.readFileSync(STATE_FILE, 'utf8');
    const data = JSON.parse(raw);
    STATE = data;
    if (!STATE.world) STATE.world = G.createWorld();
    console.log(`[load] state loaded, ${Object.keys(STATE.players).length} players`);
  } catch (e) {
    console.log('[load] no state, fresh start');
    STATE.world = G.createWorld();
  }
}
let saveScheduled = false;
function saveState() {
  if (saveScheduled) return;
  saveScheduled = true;
  setImmediate(() => {
    saveScheduled = false;
    try {
      fs.writeFileSync(STATE_FILE, JSON.stringify(STATE), 'utf8');
    } catch (e) {
      console.error('[save] error:', e.message);
    }
  });
}

// ============== АУТЕНТИФИКАЦИЯ (упрощённая) ==============
function newSessionId() {
  return crypto.randomBytes(16).toString('hex');
}
function hashPassword(pwd) {
  return crypto.createHash('sha256').update(pwd + 'twwk_salt').digest('hex');
}

// ============== HTTP REST API ==============

function send(res, status, data, headers={}) {
  const body = typeof data === 'string' ? data : JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': typeof data === 'string' ? 'text/html; charset=utf-8' : 'application/json; charset=utf-8', ...headers });
  res.end(body);
}

function readJSON(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', c => { body += c; if (body.length > 1e6) { req.destroy(); reject(new Error('too big')); } });
    req.on('end', () => {
      try { resolve(body ? JSON.parse(body) : {}); }
      catch (e) { reject(e); }
    });
    req.on('error', reject);
  });
}

function getSession(req) {
  const c = req.headers.cookie || '';
  const m = c.match(/sid=([a-f0-9]+)/);
  if (!m) return null;
  const sid = m[1];
  const username = STATE.sessions[sid];
  if (!username) return null;
  const player = STATE.players[username];
  if (!player) return null;
  return { sid, username, player };
}

// Маршруты
async function handleApi(req, res, pathname) {
  // /api/register {username, password, race, kingdom}
  if (pathname === '/api/register' && req.method === 'POST') {
    const body = await readJSON(req);
    const { username, password, race, kingdom } = body;
    if (!username || username.length < 3) return send(res, 400, { error: 'Имя пользователя минимум 3 символа' });
    if (!password || password.length < 4) return send(res, 400, { error: 'Пароль минимум 4 символа' });
    if (!race || !G.RACES[race]) return send(res, 400, { error: 'Неверная раса' });
    if (!kingdom || kingdom.length < 2) return send(res, 400, { error: 'Имя королевства минимум 2 символа' });
    if (STATE.players[username]) return send(res, 400, { error: 'Имя занято' });

    const player = G.createPlayer(race, kingdom);
    player.username = username;
    player.passwordHash = hashPassword(password);
    const pos = G.placePlayerOnWorld(STATE.world, username, race);
    player.worldPos = pos;
    if (pos) {
      const k = `${pos.q},${pos.r}`;
      STATE.world[k].player = username;
    }
    STATE.players[username] = player;
    const sid = newSessionId();
    STATE.sessions[sid] = username;
    saveState();
    return send(res, 200, { ok: true, username, kingdom }, { 'Set-Cookie': `sid=${sid}; Path=/; HttpOnly; Max-Age=2592000; SameSite=Lax` });
  }

  // /api/login {username, password}
  if (pathname === '/api/login' && req.method === 'POST') {
    const body = await readJSON(req);
    const { username, password } = body;
    const player = STATE.players[username];
    if (!player) return send(res, 401, { error: 'Неверный логин или пароль' });
    if (player.passwordHash !== hashPassword(password)) return send(res, 401, { error: 'Неверный логин или пароль' });
    const sid = newSessionId();
    STATE.sessions[sid] = username;
    saveState();
    return send(res, 200, { ok: true, username, kingdom: player.kingdom },
      { 'Set-Cookie': `sid=${sid}; Path=/; HttpOnly; Max-Age=2592000; SameSite=Lax` });
  }

  // /api/logout
  if (pathname === '/api/logout' && req.method === 'POST') {
    const sess = getSession(req);
    if (sess) delete STATE.sessions[sess.sid];
    saveState();
    return send(res, 200, { ok: true }, { 'Set-Cookie': 'sid=; Path=/; Max-Age=0' });
  }

  // Всё ниже — требует аутентификации
  const sess = getSession(req);
  if (!sess) return send(res, 401, { error: 'Не авторизован' });
  const p = sess.player;
  G.tickPlayer(p, STATE.world);
  saveState();

  // /api/state — состояние игрока + видимые куски мира
  if (pathname === '/api/state' && req.method === 'GET') {
    return send(res, 200, {
      player: serializePlayer(p),
      world: serializeWorld(p),
    });
  }

  // /api/build {loc,q,r,bldId}
  if (pathname === '/api/build' && req.method === 'POST') {
    const body = await readJSON(req);
    const r = G.cmdBuild(p, body);
    if (r.ok) saveState();
    return send(res, r.ok ? 200 : 400, r);
  }

  // /api/demolish
  if (pathname === '/api/demolish' && req.method === 'POST') {
    const body = await readJSON(req);
    const r = G.cmdDemolish(p, body);
    if (r.ok) saveState();
    return send(res, r.ok ? 200 : 400, r);
  }

  // /api/train
  if (pathname === '/api/train' && req.method === 'POST') {
    const body = await readJSON(req);
    const r = G.cmdTrain(p, body);
    if (r.ok) saveState();
    return send(res, r.ok ? 200 : 400, r);
  }

  // /api/attack {targetQ, targetR, units}
  if (pathname === '/api/attack' && req.method === 'POST') {
    const body = await readJSON(req);
    const r = G.cmdAttack(p, STATE.world, body);
    if (r.ok) saveState();
    return send(res, r.ok ? 200 : 400, r);
  }

  // /api/speed-build {jobIndex} — ускорение постройки за золото
  if (pathname === '/api/speed-build' && req.method === 'POST') {
    const body = await readJSON(req);
    const idx = body.jobIndex || 0;
    const job = p.queue[idx];
    if (!job) return send(res, 400, { error: 'нет работы' });
    const remainingSec = (job.end - Date.now()) / 1000;
    const cost = Math.max(5, Math.ceil(remainingSec / 60) * 10);
    if (p.res.gold < cost) return send(res, 400, { error: 'недостаточно золота' });
    p.res.gold -= cost;
    job.end = Date.now() + Math.floor((job.end - Date.now()) / 2);
    saveState();
    return send(res, 200, { ok: true, cost });
  }

  return send(res, 404, { error: 'не найдено' });
}

// Что отдавать клиенту: его игрок + ВИДИМЫЕ части мира
function serializePlayer(p) {
  return {
    username: p.username, kingdom: p.kingdom, race: p.race,
    res: p.res, resMax: p.resMax,
    castle: p.castle, lands: p.lands,
    queue: p.queue, trainQueue: p.trainQueue,
    army: p.army, marches: p.marches,
    reports: p.reports.slice(-50),
    worldPos: p.worldPos,
    ts: p.ts,
  };
}
function serializeWorld(p) {
  return Object.values(STATE.world);
}

// ============== СТАТИКА ==============
const STATIC_DIR = path.join(__dirname, 'public');
const MIME = { '.html':'text/html', '.js':'text/javascript', '.css':'text/css', '.json':'application/json', '.png':'image/png', '.jpg':'image/jpeg' };

function serveStatic(req, res, pathname) {
  let p = pathname === '/' ? '/index.html' : pathname;
  const file = path.join(STATIC_DIR, p);
  // защита от path traversal
  if (!file.startsWith(STATIC_DIR)) return send(res, 403, 'forbidden');
  fs.readFile(file, (err, data) => {
    if (err) return send(res, 404, 'not found');
    const ext = path.extname(p).toLowerCase();
    res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
    res.end(data);
  });
}

// ============== HTTP SERVER ==============
const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url);
  const pathname = parsed.pathname;
  try {
    if (pathname.startsWith('/api/')) {
      await handleApi(req, res, pathname);
    } else {
      serveStatic(req, res, pathname);
    }
  } catch (e) {
    console.error('[http]', e);
    send(res, 500, { error: e.message });
  }
});

// ============== WEBSOCKET ==============
const wsClients = new Map(); // username -> WSClient

wss.attach(server, (client, req) => {
  // Берём sid из cookie
  const cookie = (req.headers.cookie || '');
  const m = cookie.match(/sid=([a-f0-9]+)/);
  if (!m) { client.close(); return; }
  const username = STATE.sessions[m[1]];
  if (!username || !STATE.players[username]) { client.close(); return; }

  wsClients.set(username, client);
  client.send(JSON.stringify({ type: 'hello', username }));

  client.onMessage = (msg) => {
    try {
      const m = JSON.parse(msg);
      if (m.type === 'ping') client.send(JSON.stringify({ type: 'pong' }));
    } catch {}
  };
  client.onClose = () => {
    if (wsClients.get(username) === client) wsClients.delete(username);
  };
});

function broadcast(username, msg) {
  const c = wsClients.get(username);
  if (c) c.send(JSON.stringify(msg));
}

// ============== ИГРОВОЙ ЦИКЛ ==============
// Раз в секунду тикаем всех игроков и шлём состояния тем кто онлайн.
setInterval(() => {
  for (const username of Object.keys(STATE.players)) {
    const p = STATE.players[username];
    const reportsBefore = p.reports.length;
    G.tickPlayer(p, STATE.world);

    // Если есть подключённый WS — шлём апдейт
    if (wsClients.has(username)) {
      broadcast(username, {
        type: 'state',
        player: serializePlayer(p),
      });
      // Если появились новые отчёты — отдельным сообщением (для уведомлений)
      if (p.reports.length > reportsBefore) {
        const newReports = p.reports.slice(reportsBefore);
        broadcast(username, { type: 'reports', items: newReports });
      }
    }
  }
}, 1000);

// Авто-сохранение каждые 10 секунд (на случай если saveState не вызвался)
setInterval(() => { saveState(); }, 10000);

// ============== СТАРТ ==============
loadState();
server.listen(PORT, () => {
  console.log(`[server] Третий Мир — слушаю http://localhost:${PORT}`);
  console.log(`[server] State: ${STATE_FILE}`);
});

process.on('SIGINT', () => {
  console.log('\n[server] saving and exiting...');
  try { fs.writeFileSync(STATE_FILE, JSON.stringify(STATE), 'utf8'); } catch(e) {}
  process.exit(0);
});
